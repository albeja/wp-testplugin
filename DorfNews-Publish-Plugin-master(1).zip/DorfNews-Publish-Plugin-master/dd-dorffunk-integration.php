<?php
/**
* Plugin Name: DD-DorfFunk-Integration-Plugin
* Plugin URI: http://www.digitale-doerfer.de/
* Description: The plugin handling the submission of posts to DorfFunk.
* Version: 0.0
* Author: Matthias Koch
* Author URI: 
* License: 
*/

//defines
define( 'DD_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );

//includes
require_once( DD_PLUGIN_PATH . '/admin-menu.php' );

if ( ! function_exists('write_log')) {
    function write_log ( $log ) {
      if ( is_array( $log ) || is_object( $log ) ) {
        error_log( print_r( $log, true ) );
    } else {
        error_log( $log );
      }
    }
  }

//-------------------------------------------------//
// Add checkbox to post publish
//-------------------------------------------------//

add_action('post_submitbox_misc_actions', 'createDorfFunkCheckbox');
add_action('save_post', 'saveDorfFunkCheckbox');

function createDorfFunkCheckbox()
{
    $post_id = get_the_ID();
    $postType = get_post_type($post_id);
  
    if ($postType != 'post' && $postType != 'news' && $postType != 'dd_news' && $postType != 'tribe_events' && $postType != 'lsvr_event') {
        return;
    }
  
    $value = get_post_meta($post_id, 'dd_to_publish_on_dorffunk', true);
    wp_nonce_field('dd_publish_on_dorffunk_nonce'.$post_id, 'dd_publish_on_dorffunk_nonce');
    ?>
    <div class="misc-pub-section misc-pub-section-last">
        <label><input type="checkbox" value="1" <?php checked($value, true, true); ?> name="dd_to_publish_on_dorffunk" /><?php _e('Beitrag im <b>DorfFunk</b> ver&ouml;ffentlichen', 'pmg'); ?></label>
    </div>
    <?php
}

function saveDorfFunkCheckbox($post_id)
{
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    
    if (
        !isset($_POST['dd_publish_on_dorffunk_nonce']) ||
        !wp_verify_nonce($_POST['dd_publish_on_dorffunk_nonce'], 'dd_publish_on_dorffunk_nonce'.$post_id)
    ) {
        return;
    }
    
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    if (isset($_POST['dd_to_publish_on_dorffunk'])) {
        update_post_meta($post_id, 'dd_to_publish_on_dorffunk', $_POST['dd_to_publish_on_dorffunk']);
    } else {
        delete_post_meta($post_id, 'dd_to_publish_on_dorffunk');
    }
}

//-------------------------------------------------//
// Send requests to backend when posts are saved
//-------------------------------------------------//

add_action( 'save_post', 'handlePosts', 100);

function handlePosts($post_id)
{
   write_log("handlePosts");
   $post_type = get_post_type($post_id);
   if ($post_type != 'post' && $post_type != 'news' && get_post_type($post_id) != 'dd_news' && $post_type != 'tribe_events' && $post_type != 'lsvr_event') {
      return;
   }
   
   $to_publish = get_post_meta($post_id, 'dd_to_publish_on_dorffunk', true);
   $published = get_post_meta($post_id, 'dd_published_on_dorffunk', true);
   
   $post_status = get_post_status($post_id);
   if ($post_status == 'publish' && $to_publish) {
       if((class_exists( 'Tribe__Events__Main' ) && $post_type == 'tribe_events') || (class_exists( 'Lsvr_CPT_Event') && $post_type == 'lsvr_event')) {
         send_happening_to_backend($post_id);
       } else {
         send_post_to_backend($post_id);
       }
   } else if (($post_status != 'publish' || !$to_publish) && $published) {
      send_delete_to_backend($post_id);
   }
}

function dd_get_author_name($author)
{
   $authorFirstName = get_the_author_meta('first_name', $author);
   if(strlen($authorFirstName) <= 0) {
      return get_the_author_meta('nickname', $author);
   }
   $authorName = $authorFirstName;
   $authorLastName = get_the_author_meta('last_name', $author);
   if(strlen($authorLastName) > 0) {
      $authorLastName = " " . $authorLastName[0] . ".";
      $authorName .= $authorLastName;
   }
   return $authorName;
}

function send_post_to_backend($post_id)
{
   write_log("send_post_to_backend");
   
   $post = get_post($post_id);
   setup_postdata($post);
   
   //Post
   $title = html_entity_decode(wp_strip_all_tags($post->post_title, true), ENT_QUOTES|ENT_HTML5);
   $excerpt_content = has_excerpt($post_id) ? get_the_excerpt($post) : $post->post_content;
   $excerpt = html_entity_decode(strip_shortcodes(wp_strip_all_tags($excerpt_content, true)), ENT_QUOTES|ENT_HTML5);
   $text = dd_trim_characters($title . " | " . $excerpt, 250, "...");
   
   $imageUrl = get_the_post_thumbnail_url($post_id, 'large');
   $imageURLs = $imageUrl != false ? array($imageUrl) : null;

   $currentBlogId = get_current_blog_id();
   $siteURL = get_site_url($currentBlogId);
   $postType = get_post_type($post_id);
   
   //NewsItem
   $newsUrl = get_permalink($post_id);

   if($postType === 'dd_news') {
      $categoriesString = "Aktuelles";
   } else {
      $categories = wp_get_post_categories($post_id, array('fields' => 'names'));
      $categoriesString = !empty($categories) ? htmlspecialchars_decode($categories[0]) : "";
   }

   $authorName = dd_get_author_name($post->post_author);
   
   //POST call to backend
   $service_url = DD_BACKEND_URL.'/grapevine/event/newsItemPublishRequest?apiKey=' . DD_NEWS_APIKEY;
   $curl = curl_init($service_url);
   $dataArray = array(
      'geoAreaId'       => get_option('dd_geoarea_id'),
      'text'              => $text,
      'externalId'        => $post_id,
      'baseURL'           => $siteURL,
      'newsURL'           => $newsUrl,
      'authorName'        => $authorName,
      'imageURLs'         => $imageURLs,
      'categories'        => $categoriesString
   );
   $curl_post_data = wp_json_encode($dataArray, JSON_UNESCAPED_UNICODE);
   if(json_last_error() != JSON_ERROR_NONE) {
      write_log("ERROR encoding json: " . json_last_error_msg());
      return;
   }
   curl_setopt($curl, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
   curl_setopt($curl, CURLOPT_FAILONERROR, true);
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
   curl_setopt($curl, CURLOPT_POST, true);
   curl_setopt($curl, CURLOPT_POSTFIELDS, $curl_post_data);
   curl_setopt($curl, CURLOPT_HTTPHEADER, array(
      'Content-Type: application/json',
      'Content-Length: ' . strlen($curl_post_data)
   ));
   $curl_response = curl_exec($curl);
   if (curl_errno($curl) != CURLE_OK) {
      write_log("ERROR send_post_to_backend: " . curl_error($curl));
      write_log("Data was :");
      write_log($dataArray);
      curl_close($curl);
      return;
   }
   curl_close($curl);
   $decoded = json_decode($curl_response);
   if(json_last_error() != JSON_ERROR_NONE) {
      write_log("ERROR decoding json: " . json_last_error_msg());
      write_log($decoded);
      return;
   }
   update_post_meta($post_id, 'dd_published_on_dorffunk', 1);
   update_post_meta($post_id, 'ddBackendPostId', esc_attr($decoded->{'postId'})); // TODO:add proper error handling here
   
   write_log("send_post_to_backend finished");
}

function send_happening_to_backend($post_id)
{
    write_log("send_happening_to_backend");

    $post = get_post($post_id);
    setup_postdata($post);

    //Post
    $title = html_entity_decode(wp_strip_all_tags($post->post_title, true), ENT_QUOTES|ENT_HTML5);
    $excerpt_content = has_excerpt($post_id) ? get_the_excerpt($post) : $post->post_content;
    $excerpt = html_entity_decode(strip_shortcodes(wp_strip_all_tags($excerpt_content, true)), ENT_NOQUOTES|ENT_HTML5);
    $text = dd_trim_characters($title . " | " . $excerpt, 250, "...");

    $imageUrl = get_the_post_thumbnail_url($post_id, 'large');
    $imageURLs = $imageUrl != false ? array($imageUrl) : null;

    $currentBlogId = get_current_blog_id();
    $siteURL = get_site_url($currentBlogId);
    $postType = get_post_type($post_id);

    //NewsItem
    $newsUrl = get_permalink($post_id);

    if($postType === 'dd_news') {
      $categoriesString = "Aktuelles";
    } else {
      $categories = wp_get_post_categories($post_id, array('fields' => 'names'));
      $categoriesString = !empty($categories) ? htmlspecialchars_decode($categories[0]) : "";
    }
    
    $authorName = dd_get_author_name($post->post_author);

    // Happening data which is independent of event plugin
    $dataArray = array(
      'geoAreaId' => get_option('dd_geoarea_id'),
      'text' => $text,
      'externalId' => $post_id,
      'baseURL' => get_site_url(get_current_blog_id()),
      'newsURL' => $newsUrl,
      'authorName' => $authorName,
      'imageURLs' => $imageURLs,
      'categories' => $categoriesString
  );

    // Happening data which depends on event plugin
    if($postType == 'tribe_events') {
      $additionalData = dd_get_data_for_tribe_events($post_id);
      $dataArray = array_merge($dataArray, $additionalData);
    } elseif($postType == 'lsvr_event') {
      $additionalData = dd_get_data_for_lsvr_events($post_id);
      $dataArray = array_merge($dataArray, $additionalData);
    } else {
       return;
    }

    //POST call to backend
    $service_url = DD_BACKEND_URL . '/grapevine/event/happeningPublishRequest?apiKey=' . DD_NEWS_APIKEY;
    $curl = curl_init($service_url);
    $curl_post_data = wp_json_encode($dataArray, JSON_UNESCAPED_UNICODE);
    if (json_last_error() != JSON_ERROR_NONE) {
        write_log("ERROR encoding json: " . json_last_error_msg());
        return;
    }
    curl_setopt($curl, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
    curl_setopt($curl, CURLOPT_FAILONERROR, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $curl_post_data);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'Content-Length: ' . strlen($curl_post_data),
    ));
    $curl_response = curl_exec($curl);
    if (curl_errno($curl) != CURLE_OK) {
        write_log("ERROR send_post_to_backend: " . curl_error($curl));
        write_log("Data was :");
        write_log($dataArray);
        curl_close($curl);
        return;
    }
    curl_close($curl);
    $decoded = json_decode($curl_response);
    if (json_last_error() != JSON_ERROR_NONE) {
        write_log("ERROR decoding json: " . json_last_error_msg());
        write_log($decoded);
        return;
    }
    update_post_meta($post_id, 'dd_published_on_dorffunk', 1);
    update_post_meta($post_id, 'ddBackendPostId', esc_attr($decoded->{'postId'})); // TODO:add proper error handling here
}

function dd_get_data_for_tribe_events($post_id) {
   $venueAddress = null;

   $venue = tribe_get_venue($post_id);
   $street = tribe_get_address($post_id);
   $city = tribe_get_city($post_id);
   $zip = tribe_get_zip($post_id);

   if(!empty($venue) && !empty($street) && !empty($city) && !empty($zip)) {
       $venueAddress = array(
         'city' => $city,
         'name' => $venue,
         'street' => $street,
         'zip' => $zip,
       );
   }

   $allDayEvent = Tribe__Date_Utils::is_all_day(get_post_meta($post_id, '_EventAllDay', true));
   $startTimeLong = strtotime(get_post_meta($post_id, '_EventStartDateUTC', true)) * 1000;
   $endTimeLong = strtotime(get_post_meta($post_id, '_EventEndDateUTC', true)) * 1000;

   $additionalData = array(
      'organizer' => (tribe_get_organizer($post_id) != "" ? tribe_get_organizer($post_id) : get_the_author_meta('display_name', get_post_field ('post_author', $post_id))),
      'venue' => tribe_get_venue($post_id),
      'venueAddress' => $venueAddress,
      'startTime' => $startTimeLong,
      'endTime' => $endTimeLong,
      'allDayEvent' => $allDayEvent
   );

   return $additionalData;
}

function dd_get_data_for_lsvr_events($post_id) {

   $allDayEvent = get_post_meta( $post_id, 'lsvr_event_allday', true );
   $startTimeLong = strtotime(get_date_from_gmt(get_post_meta( $post_id, 'lsvr_event_start_date_utc', true ))) * 1000;
   $endTimeLong = strtotime(get_date_from_gmt(get_post_meta( $post_id, 'lsvr_event_end_date_utc', true ))) * 1000;

   /*
   //venueAddress not submitted until backend is compatible to locations without proper address
   $event_location_term = wp_get_post_terms( $post_id, 'lsvr_event_location' );
   if(count($event_location_term) > 0 && !empty($event_location_term[0]->name)) {
      $venueName = $event_location_term[0]->name;
   }
   $location_meta_data = lsvr_events_get_event_location_meta( $post_id );
   if(isset($location_meta_data['latitude']) && isset($location_meta_data['longitude'])) {
      $venueAddress = array(
         'venue' => $venueName,
         'gpsLocation' => array(
            'latitude' => $location_meta_data['latitude'],
            'longitude' => $location_meta_data['longitude']
         )
      );
   }
   */

   $additionalData = array(
      'organizer' => get_the_author_meta('display_name', get_post_field ('post_author', $post_id)),
      //'venueAddress' => $venueAddress, //venueAddress not submitted until backend is compatible to locations without proper address
      'startTime' => $startTimeLong,
      'endTime' => $endTimeLong,
      'allDayEvent' => $allDayEvent
   );

   return $additionalData;
}

/**
 * Properly trim characters of a string up to word boundary
 *
 * @param string $text        String to be truncated
 * @param int    $number      Maximal number of characters
 * @param string $ending        String which is appended on truncated text
 * @return string The processed string.
 */
function dd_trim_characters($text, $number, $ending) {
   $trimmed_text = trim($text);
   $len = strlen($trimmed_text);
   if($len <= $number) {
      return $trimmed_text;
   }
   $len_ending = strlen($ending);
   $number_ending = $number - $len_ending;

   // REGEX:  get up to $number characters from the start of string up to a word boundary
   if (preg_match('/^.{1,'.$number_ending.'}\b/su', $trimmed_text, $match)) {
      $return = trim($match[0]);
   } else {
      $return = mb_substr($trimmed_text, 0, $number_ending);
   }
   $return = $return.$ending;
   return $return;
}

add_action( 'before_delete_post', 'send_delete_to_backend' );

function send_delete_to_backend($post_id)
{
   if(metadata_exists('post', $post_id, 'ddBackendPostId')) {   //do not try to send delete requests to backend for posts, that never reached the backend before, i.e. do not have a newsItemId
      $postId = get_post_meta($post_id, 'ddBackendPostId', true);
      
      //DELETE call to backend
      $service_url = DD_BACKEND_URL.'/grapevine/event/externalPostDeleteRequest?apiKey=' . DD_NEWS_APIKEY;
      $curl = curl_init($service_url);
      $dataArray = array(
         'postId'    => $postId
      );
      $curl_post_data = wp_json_encode($dataArray);
      if(json_last_error() != JSON_ERROR_NONE) {
         write_log("ERROR encoding json: " . json_last_error_msg());
         return;
      }
      curl_setopt($curl, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
      curl_setopt($curl, CURLOPT_FAILONERROR, true);
      curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($curl, CURLOPT_POST, true);
      curl_setopt($curl, CURLOPT_POSTFIELDS, $curl_post_data);
      curl_setopt($curl, CURLOPT_HTTPHEADER, array(
         'Content-Type: application/json',                                                                                
         'Content-Length: ' . strlen($curl_post_data)
      ));
      $curl_response = curl_exec($curl);
      if (curl_errno($curl) != CURLE_OK) {
          write_log("ERROR send_post_to_backend: " . curl_error($curl));
          write_log("Data was :");
          write_log($dataArray);
          curl_close($curl);
          return;
      }
      curl_close($curl);
      $decoded = json_decode($curl_response);
      if(json_last_error() != JSON_ERROR_NONE) {
         write_log("ERROR decoding json: " . json_last_error_msg());
         write_log($decoded);
         return;
      }
      update_post_meta($post_id, 'dd_published_on_dorffunk', 0);
   }
}

?>
