<?php

//-------------------------------------------------//
/* Admin menu */
//-------------------------------------------------//

add_action( 'admin_menu', 'dd_news_admin_menu' );

function dd_news_admin_menu() {
	if(!class_exists( 'DD_Sync_User')) { //only add new menu, if menu in dd-sync is not present
		//create new top-level menu
		add_menu_page( 'Digitale D&ouml;rfer Konfiguration','Digitale D&ouml;rfer Konfiguration',
			'manage_options', 'digitale-doerfer', 'dd_news_plugin_options');
		} else {
			add_action('dd_admin_menu_settings_after_dd_community_id', 'dd_news_plugin_options');
		}

	//call register settings function
	add_action( 'admin_init', 'register_dd_news_plugin_settings' );
}


function register_dd_news_plugin_settings() {
	//register settings
	if(!class_exists( 'DD_Sync_User')) {	//community id already in sync user plugin
		register_setting( 'dd-plugin-settings-group', 'dd_community_id' );
	}
	register_setting( 'dd-plugin-settings-group', 'dd_geoarea_id' );
}

function dd_news_plugin_options() {
	if ( !current_user_can( 'manage_options' ) )  {
		wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
	}

	if(!class_exists( 'DD_Sync_User')) { //only add new menu, if menu in dd-sync is not present

	//settings page
	?>
	<div class="wrap">
	<h1>Digitale D&ouml;rfer Plugin Konfiguration</h1>
	<p>Environment: <?php echo DD_BACKEND_URL; ?></p>

	<form method="post" action="options.php">
		<?php settings_fields( 'dd-plugin-settings-group' ); ?>
		<?php do_settings_sections( 'dd-plugin-settings-group' ); ?>
		<table class="form-table">
			<tr valign="top">
			<th scope="row">Community ID</th>
			<td><input type="text" name="dd_community_id" class="regular-text" value="<?php echo esc_attr( get_option('dd_community_id') ); ?>" /></td>
			</tr>
			<tr valign="top">
			<th scope="row">Geo Area ID</th>
			<td><input type="text" name="dd_geoarea_id" class="regular-text" value="<?php echo esc_attr( get_option('dd_geoarea_id') ); ?>" /></td>
			</tr>
		</table>
		<?php submit_button(); ?>
	</form>
	</div>
	<?php
	} else {
		?>
			<tr valign="top">
			<th scope="row">Geo Area ID</th>
			<td><input type="text" name="dd_geoarea_id" class="regular-text" value="<?php echo esc_attr( get_option('dd_geoarea_id') ); ?>" /></td>
			</tr>
		<?php
	}
}

?>